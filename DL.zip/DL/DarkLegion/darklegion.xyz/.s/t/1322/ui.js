$(function($){  
    $('#catmenu').prepend('<div class="nav-head"><div class="icon"><span></span><span></span><span></span><span></span></div><a href="#">'+navTitle+'</a></div>');
    var parentLi = $('#catmenu li.uWithSubmenu');
    $('> a',parentLi).after('<em>+</em>');
    $('> em',parentLi).click(function(){
        if ( $(this).text() == '+') {
          $(this).parent().addClass('over');
          $(this).text('-');
        } else {
          $(this).parent().removeClass('over');
          $(this).text('+');
        }
    });
    $('.nav-head').click(function(){
        $(this).toggleClass('over');
        return false;
    });
});
$(function($){
      $('.sidebox ul.cat-tree').removeAttr('style').removeClass('cat-tree');
    var sdLi = $('.sidebox li:has(ul)').addClass('parent-li');
    $(sdLi).each(function() {
            $(this).prepend('<em>+</em>');
        });
    $('> em',sdLi).click(function() {     
        if ( $(this).text() == '+') {
          $(this).parent().addClass('over');
          $(this).text('-');
        } else {
          $(this).parent().removeClass('over');
          $(this).text('+');
        }
    });
});
$('.site-n a').click(function(e){
        if ($('span', this).hasClass('uz-signs')) {
        e.preventDefault()
    }
});