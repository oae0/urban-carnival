e=document.getElementsByTagName('BODY');
for (k=0; k<e.length; k++) {
s=e[k].innerHTML; 
while (s.indexOf('[green]') != -1 || s.indexOf('[blue]') != -1 || s.indexOf('[gray]') != -1 || s.indexOf('[red]') != -1) { 
s=s.replace('[green]','<div class="green">'); s=s.replace('[/green]','</div>'); 
s=s.replace('[red]','<div class="red">'); s=s.replace('[/red]','</div>'); 
s=s.replace('[gray]','<div class="gray">'); s=s.replace('[/gray]','</div>');
s=s.replace('[blue]','<div class="blue">'); s=s.replace('[/blue]','</div>');
e[k].innerHTML=s;
}
}